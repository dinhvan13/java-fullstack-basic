<template>
  <v-container>
    day la trang helloworld
  </v-container>
</template>

<script>
export default {
  name: "HelloWorld",

  data: () => ({
  
  }),
};
</script>
