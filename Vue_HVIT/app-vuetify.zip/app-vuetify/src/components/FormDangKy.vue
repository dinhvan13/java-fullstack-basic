<template>

  <div class="container d-flex justify-center "  style="max-width:400px; border:1px solid red;margin-top:20px;">
    <h1 style="color:green; text-align:center;font-weight:bold; padding-top:10px;">REGISTER</h1>
    <br>
  <v-app>
  <v-form  ref="form"
    v-model="valid"
    lazy-validation>
    <v-text-field
      v-model="name"
      :counter="30"
      label="Name"
      :rules="nameRules"
      required
    ></v-text-field>

    <v-text-field
          v-model="age"
          label="Age"
          required
          type ="number"
          min = "0"
          max = "100"
         :rules="ageRules"
        ></v-text-field>
    <label for="Sports">My Favorites</label>
    <p>{{ selected }}</p>
    <v-checkbox
      v-model="selected"
      label="Sports"
      value="Sports"
      
    ></v-checkbox>
    <v-checkbox
      v-model="selected"
      label="Music"
      value="Music"
    ></v-checkbox>
    <v-checkbox
      v-model="selected"
      label="Go Fishing"
      value="Go Fishing"
    ></v-checkbox>
    
    <v-text-field
      v-model="email"
      label="E-mail"
      required
      :rules="emailRules"
    ></v-text-field>

    <label>Gender</label><br>
    <v-radio-group
      v-model="row"
      row
    >
      <v-radio
        label="Nam"
        value="nam"
      ></v-radio>
      <v-radio
        label="Nu"
        value="nu"
      ></v-radio>
    </v-radio-group>
       <v-col
        class="d-flex"
        cols="12"
        sm="6"
      >
   
       <v-select
          :items="items"
          label="City"
          :rules ="[v => !! v || 'Item is required']"
           dense
          outlined
        ></v-select>
        </v-col>

    <!-- <label>Birthday </label><br>
    <v-date-picker v-model="picker"
    > -->

    <!-- </v-date-picker> -->

     <v-textarea
     v-model="intro"
      autocomplete="intro"
      label="Introduce"
      :rules="introRules"
    ></v-textarea>
    
    
    <v-checkbox
      v-model="checkbox"
      label="Do you agree?"
      :rules = "[v => !!v || 'You must agree to continue!']"
      required
    ></v-checkbox>

    <v-btn
      class="mr-4"
      @click="submit"
    >
      submit
    </v-btn>
    <v-btn @click="clear">
      clear
    </v-btn>
  </v-form>
  </v-app>
  </div>
  
</template>
<script>
export default {
    data() {
      return {
        valid:null ,
      name: '',
      nameRules: [
        v => !!v || "Name is required!",
        v => (v && v.length <= 30) || 'Name must be lass than 30 characters',
      ]
      ,
      email: '',
      emailRules:[
         v => !!v || "Email is required",
         v => /^[a-z0-9]+(?!.*(?:\+-{.{2,}))(?:[.+-]{0,1}[a-z0-9])*@gmail.com$/gmi.test(v) || 'E-mail must be valid',
      ],
      select: null,
      checkbox: false,
      radios: null,
      age:null,
      ageRules:[
        v => (v && v >=0 && v <=100) || 'Ages must from 0 to 100 ',
      ]
      ,
      row:"nam",
      selected: [],
      items: ['Ha Noi', 'Bac Ninh', 'Ho Chi Minh', 'Khanh Hoa'],
      intro: '',
      introRules: [
        v => !!v || "Intro is required!",
        v => (v && v.length <= 150) || 'Name must be lass than 150 characters',
      ]
      ,
      picker: new Date().toISOString().substr(0, 10),
      }
    },
    

    computed: {
     
    },
    watch:{
       picker(){
         console.log(this.picker)
       }
    },

    methods: {
     clear(){
          this.$refs.form.reset();
     },
     submit(){
       this.$refs.form.validate();
     }
    },
  
}
</script>
<style scoped>
button{
      margin-right: 15px;
}
</style>