<template>
  <div class="container">
    <nav-bar></nav-bar>
    <router-view></router-view>
    </div>
    

  
</template>

<script>
import NavBar from './components/NavBar.vue';
export default {
  components: { NavBar },
  name: "App",

  data: () => ({
    //
  }),
};
</script>
