<template>
  <v-container>
    <v-row>
      <v-col cols="8">
        <v-card class="card">
          <v-row>
            <v-col cols="4">
              <v-img
                src="https://danviet.mediacdn.vn/upload/2-2017/images/2017-06-22/149812210592573-00.jpg"
                height="300px"
                max-width="380px"
              ></v-img>
            </v-col>
            <v-col cols="8">
              <v-card-title style="margin-bottom:3px;"> Honda Brio 1.2RS </v-card-title>
              <v-card-subtitle>
                <h3 style="color: red">Price: 450.000.000 đ</h3>

                <p>
                  Thay đổi chuẩn mực thiết kế với những chi tiết thể thao và phong cách, phần sau
                  của xe toát lên vẻ khỏe khoắn và mạnh mẽ cho chủ nhân thu hút mọi ánh nhìn đầy
                  ngưỡng mộ.
                </p>
              </v-card-subtitle>
              <v-card-actions>
                <div class="btn">
                  <v-btn
                    class="ml-2 mt-5"
                    outlined
                    rounded
                    small
                    text
                    color="white"
                    style="background-color: red"
                  >
                    Show More
                  </v-btn>
                </div>
              </v-card-actions>
            </v-col>
          </v-row>
        </v-card>

        <v-card class="card">
          <v-row>
            <v-col cols="4">
              <v-img
                src="https://giaxeoto.vn/admin/webroot/img/upload2/gia-xe-honda-city-2021.jpg"
                height="300px"
                max-width="380px"
              ></v-img>
            </v-col>
            <v-col cols="8">
              <v-card-title style="margin-bottom:3px;"> Honda City 1.5G </v-card-title>

              <v-card-subtitle>
                <h3 style="color: red">Price: 670.000.000 đ</h3>
        
                <p>
                  Bước vào bên trong Honda Brio bạn sẽ bị ấn tượng bởi sự sang trọng và sự tiện
                  nghi. Những trang bị cao cấp cùng những điểm nhấn tinh tế nhưng không kém phần thể
                  thao giúp hoàn thiện trải nghiệm đầy cảm hứng cho chủ nhân.
                </p>
              </v-card-subtitle>
              <v-card-actions>
                <div class="btn">
                  <v-btn
                    class="ml-2 mt-5"
                    outlined
                    rounded
                    small
                    text
                    color="white"
                    style="background-color: red"
                  >
                    Show More
                  </v-btn>
                </div>
              </v-card-actions>
            </v-col>
          </v-row>
        </v-card>

        <v-card class="card">
          <v-row>
            <v-col cols="4">
              <v-img
                src="https://cms-i.autodaily.vn/du-lieu/2020/11/26/honda-city.jpg"
                height="300px"
                max-width="380px"
              ></v-img>
            </v-col>
            <v-col cols="8">
              <v-card-title style="margin-bottom:3px;"> Honda Civic 1.5L TURBO </v-card-title>

              <v-card-subtitle>
                <h3 style="color: red">Price: 100.000.000 đ</h3>
       
                <p>
                  Bước vào bên trong Honda Brio bạn sẽ bị ấn tượng bởi sự sang trọng và sự tiện
                  nghi. Những trang bị cao cấp cùng những điểm nhấn tinh tế nhưng không kém phần thể
                  thao giúp hoàn thiện trải nghiệm đầy cảm hứng cho chủ nhân.
                </p>
              </v-card-subtitle>
              <v-card-actions>
                <div class="btn">
                  <v-btn
                    class="ml-2 mt-5"
                    outlined
                    rounded
                    small
                    text
                    color="white"
                    style="background-color: red"
                  >
                    Show More
                  </v-btn>
                </div>
              </v-card-actions>
            </v-col>
          </v-row>
        </v-card>

        <v-card class="card">
          <v-row>
            <v-col cols="4">
              <v-img
                src="https://image.bnews.vn/MediaUpload/Medium/2019/04/02/113144-113002-cvs19-201.jpg"
                height="300px"
                max-width="380px"
              ></v-img>
            </v-col>
            <v-col cols="8">
              <v-card-title style="margin-bottom:3px;"> Honda City 1.5G</v-card-title>

              <v-card-subtitle>
                <h3 style="color: red">Price: 538.000.000 đ</h3>
    
                <p>
                  Bước vào bên trong Honda Brio bạn sẽ bị ấn tượng bởi sự sang trọng và sự tiện
                  nghi. Những trang bị cao cấp cùng những điểm nhấn tinh tế nhưng không kém phần thể
                  thao giúp hoàn thiện trải nghiệm đầy cảm hứng cho chủ nhân.
                </p>
              </v-card-subtitle>
              <v-card-actions>
                <div class="btn">
                  <v-btn
                    class="ml-2 mt-5"
                    outlined
                    rounded
                    small
                    text
                    color="white"
                    style="background-color: red"
                  >
                    Show More
                  </v-btn>
                </div>
              </v-card-actions>
            </v-col>
          </v-row>
        </v-card>
      </v-col>

      <v-col cols="4">
        <div class="text-center">
          <v-toolbar color="primary" dark="true" rounded shaped outlined>
            <v-icon color="white" class="toolbar-icon">mdi-account-circle</v-icon>
            <v-toolbar-title class="toolar-title">About & Social</v-toolbar-title>
          </v-toolbar>
        </div>
        <v-card width="561">
          <v-img
            src="https://freetuts.net/upload/product_series/images/2019/11/26/308/honda-city-2020-mau-do_800x450.jpg"
            class="white--text align-end v-img"
            gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
            height="295px"
            width="600"
          >
            <v-card-title class="card-title">Best Sell 2021</v-card-title>
          </v-img>
        </v-card>
        <div class="icon">
          <v-btn class="icon-btn" rounded-xl color="error" width="130px" height="45px" dark>
            <v-icon>mdi-google</v-icon>
          </v-btn>
          <v-btn class="icon-btn" rounded-xl color="primary" width="130px" height="45px" dark>
            <v-icon>mdi-facebook</v-icon>
          </v-btn>
          <v-btn class="icon-btn-last" rounded-xls color="#00BCD4" width="130px" height="45px" dark>
            <v-icon>mdi-twitter</v-icon>
          </v-btn>
        </div>

        <div class="text-center-two">
          <v-toolbar color="primary" dark="true" rounded shaped outlined>
            <v-icon color="white" class="toolbar-icon">mdi-tag</v-icon>
            <v-toolbar-title class="toolar-title">News Popular</v-toolbar-title>
          </v-toolbar>
        </div>
        <v-row>
          <v-col>
            <v-card class="mx-auto" max-width="550" tile>
              <v-list>
                <v-subheader>Today</v-subheader>
                <v-list-item-group v-model="selectedItem" color="primary">
                  <template v-for="(item, index) in items.slice(0, 12)">
                    <v-subheader v-if="item.header" :key="item.header">
                      {{ item.header }}
                    </v-subheader>
                    <v-divider
                      v-else-if="item.divider"
                      :key="index"
                      :inset="item.inset"
                    ></v-divider>
                    <v-list-item v-else :key="item.title">
                      <v-list-item-avatar>
                        <img :src="item.avatar" />
                      </v-list-item-avatar>
                      <v-list-item-content>
                        <v-list-item-title v-html="item.title"></v-list-item-title>
                        <v-list-item-subtitle v-html="item.subtitle"></v-list-item-subtitle>
                      </v-list-item-content>
                    </v-list-item>
                  </template>
                </v-list-item-group>
              </v-list>
            </v-card>
          </v-col>
        </v-row>
      </v-col>
    </v-row>
    <v-btn @click="topFunction()" id="myBtn" title="Go to top">Top</v-btn>
  </v-container>
</template>
<style scoped>
.btn {
  margin-top: 85px;
  margin-left: 600px;
}
.card {
  margin-bottom: 30px;
}
.ma-2 {
  width: 550px;
  height: 50px !important;
  font-weight: bold;
  font-size: 20px !important;
}
.text-center {
  margin-top: -17px;
  margin-left: -7px;
  margin-bottom: 5px;
}
.card-title {
  padding-left: 200px;
}
.icon {
  margin-top: 30px;
}
.icon-btn {
  margin-right: 50px;
  margin-left: 25px;
}
.text-center-two {
  margin-top: 20px;
  margin-bottom: 5px;
}
.toolar-title {
  color: white;
}
.v-img {
  margin-left: 0px !important;
  margin-right: 10px !important;
}
.toolbar-icon {
  padding-right: 10px;
}
#myBtn {
  display: none;
  position: fixed;
  bottom: 20px;
  right: 30px;
  z-index: 99;
  font-size: 18px;
  border: none;
  outline: none;
  background-color: red;
  color: white;
  cursor: pointer;
  padding: 15px;
  border-radius: 4px;
}

#myBtn:hover {
  background-color: #555;
}
</style>
<script>
export default {
  data: () => ({
    selectedItem: 1,
    items: [
      {
        avatar: "https://hondaoto5squangninh.net/upload/images/F3_(1)1_thumb.png",
        title: "Brunch this weekend?",
        subtitle: `<span class="font-weight-bold">Ali Connors</span> &mdash; I'll be in your neighborhood doing errands this weekend. Do you want to hang out?`,
      },
      { divider: true, inset: true },
      {
        avatar: "https://cdn.vuetifyjs.com/images/lists/2.jpg",
        title: 'Summer BBQ <span class="grey--text text--lighten-1">4</span>',
        subtitle: `<span class="font-weight-bold">to Alex, Scott, Jennifer</span> &mdash; Wish I could come, but I'm out of town this weekend.`,
      },
      { divider: true, inset: true },
      {
        avatar: "https://cdn.vuetifyjs.com/images/lists/3.jpg",
        title: "Oui oui",
        subtitle:
          '<span class="font-weight-bold">Sandra Adams</span> &mdash; Do you have Paris recommendations? Have you ever been?',
      },
      { divider: true, inset: true },
      {
        avatar: "https://cdn.vuetifyjs.com/images/lists/1.jpg",
        title: "Brunch this weekend?",
        subtitle: `<span class="font-weight-bold">Ali Connors</span> &mdash; I'll be in your neighborhood doing errands this weekend. Do you want to hang out?`,
      },
      { divider: true, inset: true },
      {
        avatar: "https://cdn.vuetifyjs.com/images/lists/2.jpg",
        title: 'Summer BBQ <span class="grey--text text--lighten-1">4</span>',
        subtitle: `<span class="font-weight-bold">to Alex, Scott, Jennifer</span> &mdash; Wish I could come, but I'm out of town this weekend.`,
      },
    ],
  }),
  methods: {
    
  },
};


</script>
