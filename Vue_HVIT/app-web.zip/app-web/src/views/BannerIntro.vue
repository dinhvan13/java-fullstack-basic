<template>
<v-container style="display: flex;
    flex-direction: row;">
  <v-card
    class="mx-auto"
    max-width="400" style="margin-left:0px !important ; padding-left:0px"
  >
    <v-img
      class="white--text align-end"
      height="200px"
      src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRuT2ikuE3WuDSjs5nx17twEaUn_xx9tNWPcg&usqp=CAU"
    >
      <v-card-title>Top 4 Global World Cars</v-card-title>
    </v-img>

    <v-card-subtitle class="pb-0">
      Number 1
    </v-card-subtitle>

    <v-card-text class="text--primary">
      <div>HonDa Cars</div>

      <div>Honda CR-V 1.5L</div>
    </v-card-text>

    <v-card-actions>
      <v-btn
        color="orange"
        text
      >
        Show
      </v-btn>

      <v-btn
        color="orange"
        text
      >
        Order
      </v-btn>
    </v-card-actions>
  </v-card>

  <v-card
    class="mx-auto"
    max-width="400"
  >
    <v-img
      class="white--text align-end"
      height="200px"
      src="http://xehoihondamiennam.com/upload/ca8990ee2b16d5488c07_-05-11-2020-08-43-58.jpg"
    >
      <v-card-title>Top 4 Global World Cars</v-card-title>
    </v-img>

    <v-card-subtitle class="pb-0">
      Number 2
    </v-card-subtitle>

    <v-card-text class="text--primary">
      <div>HonDa Cars</div>

      <div>Honda Civic 1.5L TURBO</div>
    </v-card-text>

    <v-card-actions>
      <v-btn
        color="orange"
        text
      >
        Show
      </v-btn>

      <v-btn
        color="orange"
        text
      >
        Order
      </v-btn>
    </v-card-actions>
  </v-card>


  <v-card
    class="mx-auto"
    max-width="400"
  >
    <v-img
      class="white--text align-end"
      height="200px"
      src="https://honda.net.vn/wp-content/uploads/2020/03/hrv.jpg"
    >
      <v-card-title>Top 4 Global World Cars</v-card-title>
    </v-img>

    <v-card-subtitle class="pb-0">
      Number 3
    </v-card-subtitle>

    <v-card-text class="text--primary">
      <div>HonDa Cars</div>

      <div>Honda Civic 1.8G</div>
    </v-card-text>

    <v-card-actions>
      <v-btn
        color="orange"
        text
      >
        Show
      </v-btn>

      <v-btn
        color="orange"
        text
      >
        Order
      </v-btn>
    </v-card-actions>
  </v-card>

  <v-card
    class="mx-auto"
    max-width="400"
    style="margin-right:0px !important;padding-right:0px"
  >
    <v-img
      class="white--text align-end"
      height="200px"
      src="https://giaxeoto.vn/admin/webroot/img/upload2/honda-brio-gia-bao-nhieu.jpg"
    >
      <v-card-title>Top 4 Global World Cars</v-card-title>
    </v-img>

    <v-card-subtitle class="pb-0">
      Number 4
    </v-card-subtitle>

    <v-card-text class="text--primary">
      <div>HonDa Cars</div>

      <div>Honda CR-V 1.5G</div>
    </v-card-text>

    <v-card-actions>
      <v-btn
        color="orange"
        text
      >
        Show
      </v-btn>

      <v-btn
        color="orange"
        text
      >
        Order
      </v-btn>
    </v-card-actions>
  </v-card>

  </v-container>
</template>